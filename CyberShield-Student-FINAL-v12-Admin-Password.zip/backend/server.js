require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const { Server } = require('socket.io');
const { WebSocketServer } = require('ws');
const crypto = require('crypto');
const path = require('path');

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be set and at least 32 characters long.');
const origins = (process.env.CORS_ORIGINS || '*').split(',').map(x => x.trim()).filter(Boolean);

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: origins.includes('*') ? true : origins, credentials: true }));
app.use(express.json({ limit: '200kb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 25, standardHeaders: true, legacyHeaders: false });

const io = new Server(server, { cors: { origin: origins.includes('*') ? '*' : origins } });
const wss = new WebSocketServer({ server, path: '/ws' });
const wsBroadcast = payload => { const msg = JSON.stringify(payload); wss.clients.forEach(c => { if (c.readyState === 1) c.send(msg); }); };
wss.on('connection', ws => ws.send(JSON.stringify({ type: 'connected', service: 'CyberShield realtime', time: new Date().toISOString() })));

const memory = { users: [], incidents: [], feedback: [], forum: [], submissions: [], squads: [], audit: [], broadcasts: [], threats: [], skillProfiles: [], skillEvents: [] };
let dbReady = false;
let pool = null;

if (process.env.DATABASE_URL) {
  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_SSL === 'false' ? false : { rejectUnauthorized: false },
    max: Number(process.env.DB_POOL_MAX || 5),
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
  });
}

const TABLES = {
  User: 'users', Incident: 'incidents', Feedback: 'feedback', Forum: 'forum_posts',
  Submission: 'submissions', Squad: 'squads', Audit: 'audit_logs', Broadcast: 'broadcasts', Threat: 'threat_events', SkillProfile: 'skill_profiles', SkillEvent: 'skill_events'
};

async function initDb() {
  if (!pool) return;
  const sql = `
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
      country TEXT DEFAULT 'Ghana', school TEXT, xp INTEGER DEFAULT 0, role TEXT DEFAULT 'student', created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS admin_credentials (
      email TEXT PRIMARY KEY, password_hash TEXT NOT NULL, token_version INTEGER DEFAULT 0, updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS incidents (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL, category TEXT, severity TEXT,
      status TEXT DEFAULT 'Pending', tags JSONB DEFAULT '[]'::jsonb, reporter_id TEXT, reporter_name TEXT,
      ip TEXT, network_zone TEXT, risk_score INTEGER DEFAULT 0, assigned_to TEXT, admin_note TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS feedback (
      id TEXT PRIMARY KEY, category TEXT, message TEXT NOT NULL, user_id TEXT, name TEXT,
      status TEXT DEFAULT 'new', admin_reply TEXT DEFAULT '', reviewed_at TIMESTAMPTZ, replied_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS forum_posts (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, user_id TEXT, name TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS submissions (
      id TEXT PRIMARY KEY, type TEXT NOT NULL, answer TEXT NOT NULL, user_id TEXT NOT NULL,
      first_to_submit BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE UNIQUE INDEX IF NOT EXISTS submissions_user_type_idx ON submissions(type, user_id);
    CREATE TABLE IF NOT EXISTS squads (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, school TEXT DEFAULT '', country TEXT DEFAULT '', owner_id TEXT,
      members INTEGER DEFAULT 1, xp INTEGER DEFAULT 0, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id BIGSERIAL PRIMARY KEY, actor TEXT, action TEXT, target TEXT, meta JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS broadcasts (
      id TEXT PRIMARY KEY, message TEXT NOT NULL, severity TEXT DEFAULT 'info', active BOOLEAN DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS threat_events (
      id TEXT PRIMARY KEY, event_type TEXT NOT NULL, severity TEXT NOT NULL, status TEXT DEFAULT 'open', source_ip TEXT, network_zone TEXT, user_agent TEXT, path TEXT, actor TEXT, details JSONB DEFAULT '{}'::jsonb, evidence JSONB DEFAULT '{}'::jsonb, csa_status TEXT DEFAULT 'not_reported', csa_reference TEXT, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS threat_created_idx ON threat_events(created_at DESC);
    CREATE INDEX IF NOT EXISTS threat_status_idx ON threat_events(status);
    CREATE INDEX IF NOT EXISTS incidents_created_idx ON incidents(created_at DESC);
    CREATE INDEX IF NOT EXISTS feedback_created_idx ON feedback(created_at DESC);
    CREATE INDEX IF NOT EXISTS forum_created_idx ON forum_posts(created_at DESC);
    CREATE INDEX IF NOT EXISTS audit_created_idx ON audit_logs(created_at DESC);
    CREATE INDEX IF NOT EXISTS users_xp_idx ON users(xp DESC);
    CREATE TABLE IF NOT EXISTS skill_profiles (id TEXT PRIMARY KEY, user_id TEXT NOT NULL UNIQUE, mastery JSONB DEFAULT '{}'::jsonb, total_attempts INTEGER DEFAULT 0, total_completed INTEGER DEFAULT 0, updated_at TIMESTAMPTZ DEFAULT NOW());
    CREATE TABLE IF NOT EXISTS skill_events (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, skill TEXT NOT NULL, activity TEXT NOT NULL, score INTEGER NOT NULL DEFAULT 0, duration_seconds INTEGER DEFAULT 0, xp_earned INTEGER DEFAULT 0, source TEXT DEFAULT 'adaptive', created_at TIMESTAMPTZ DEFAULT NOW());
    CREATE INDEX IF NOT EXISTS skill_events_user_idx ON skill_events(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS skill_events_skill_idx ON skill_events(skill, created_at DESC);
  `;
  await pool.query(sql);
  dbReady = true;
  console.log('Supabase PostgreSQL connected');
}

initDb().catch(err => console.error('Supabase database initialization failed; using temporary memory storage:', err.message));

const columnMap = {
  User: { id:'id', name:'name', email:'email', passwordHash:'password_hash', country:'country', school:'school', xp:'xp', role:'role', createdAt:'created_at' },
  Incident: { id:'id', title:'title', description:'description', category:'category', severity:'severity', status:'status', tags:'tags', reporterId:'reporter_id', reporterName:'reporter_name', ip:'ip', networkZone:'network_zone', riskScore:'risk_score', assignedTo:'assigned_to', adminNote:'admin_note', createdAt:'created_at', updatedAt:'updated_at' },
  Feedback: { id:'id', category:'category', message:'message', userId:'user_id', name:'name', status:'status', adminReply:'admin_reply', reviewedAt:'reviewed_at', repliedAt:'replied_at', createdAt:'created_at', updatedAt:'updated_at' },
  Forum: { id:'id', title:'title', body:'body', userId:'user_id', name:'name', createdAt:'created_at' },
  Submission: { id:'id', type:'type', answer:'answer', userId:'user_id', firstToSubmit:'first_to_submit', createdAt:'created_at' },
  Squad: { id:'id', name:'name', school:'school', country:'country', ownerId:'owner_id', members:'members', xp:'xp', createdAt:'created_at' },
  Audit: { id:'id', actor:'actor', action:'action', target:'target', meta:'meta', createdAt:'created_at' },
  Broadcast: { id:'id', message:'message', severity:'severity', active:'active', createdAt:'created_at' },
  Threat: { id:'id', eventType:'event_type', severity:'severity', status:'status', sourceIp:'source_ip', networkZone:'network_zone', userAgent:'user_agent', path:'path', actor:'actor', details:'details', evidence:'evidence', csaStatus:'csa_status', csaReference:'csa_reference', createdAt:'created_at', updatedAt:'updated_at' },
  SkillProfile: {id:'id', userId:'user_id', mastery:'mastery', totalAttempts:'total_attempts', totalCompleted:'total_completed', updatedAt:'updated_at'},
  SkillEvent: {id:'id', userId:'user_id', skill:'skill', activity:'activity', score:'score', durationSeconds:'duration_seconds', xpEarned:'xp_earned', source:'source', createdAt:'created_at'}
};

function toDbValue(name, key, value) {
  if (['tags', 'meta', 'mastery'].includes(key)) return JSON.stringify(value ?? (key === 'tags' ? [] : {}));
  return value;
}
function fromRow(name, row) {
  const out = {};
  for (const [key, col] of Object.entries(columnMap[name])) {
    let v = row[col];
    if (['tags','meta','mastery'].includes(key) && typeof v === 'string') { try { v = JSON.parse(v); } catch {} }
    out[key] = v;
  }
  return out;
}

async function findOne(name, filter = {}) {
  if (!dbReady) return memoryFindOne(name, filter);
  const cols = columnMap[name];
  const entries = Object.entries(filter);
  if (!entries.length) { const r = await pool.query(`SELECT * FROM ${TABLES[name]} LIMIT 1`); return r.rows[0] ? fromRow(name, r.rows[0]) : null; }
  const where = entries.map(([k], i) => `${cols[k]} = $${i+1}`).join(' AND ');
  const values = entries.map(([k,v]) => toDbValue(name,k,v));
  const r = await pool.query(`SELECT * FROM ${TABLES[name]} WHERE ${where} LIMIT 1`, values);
  return r.rows[0] ? fromRow(name, r.rows[0]) : null;
}

async function findMany(name, filter = {}, sort = { createdAt: -1 }, limit = 100) {
  if (!dbReady) return memoryFindMany(name, filter, sort, limit);
  const cols = columnMap[name];
  const entries = Object.entries(filter);
  const values = entries.map(([k,v]) => toDbValue(name,k,v));
  const where = entries.length ? `WHERE ${entries.map(([k],i)=>`${cols[k]} = $${i+1}`).join(' AND ')}` : '';
  const sortEntry = Object.entries(sort || {createdAt:-1})[0] || ['createdAt',-1];
  const order = `${cols[sortEntry[0]] || cols.createdAt} ${sortEntry[1] === 1 ? 'ASC' : 'DESC'}`;
  const r = await pool.query(`SELECT * FROM ${TABLES[name]} ${where} ORDER BY ${order} LIMIT ${Math.max(1,Math.min(1000,Number(limit)||100))}`, values);
  return r.rows.map(row => fromRow(name,row));
}

async function count(name, filter = {}) {
  if (!dbReady) return memoryFindMany(name, filter, {createdAt:-1}, 1000000).length;
  const cols = columnMap[name]; const entries = Object.entries(filter); const values = entries.map(([k,v])=>toDbValue(name,k,v));
  const where = entries.length ? `WHERE ${entries.map(([k],i)=>`${cols[k]} = $${i+1}`).join(' AND ')}` : '';
  const r = await pool.query(`SELECT COUNT(*)::int AS count FROM ${TABLES[name]} ${where}`, values); return r.rows[0].count;
}

async function save(name, obj) {
  if (!dbReady) return memorySave(name,obj);
  const cols = columnMap[name]; const keys = Object.keys(obj).filter(k => cols[k]);
  const columns = keys.map(k=>cols[k]); const values = keys.map(k=>toDbValue(name,k,obj[k]));
  const placeholders = keys.map((_,i)=>`$${i+1}`).join(', ');
  const updates = columns.map((c,i)=>`${c} = EXCLUDED.${c}`).join(', ');
  let sql = `INSERT INTO ${TABLES[name]} (${columns.join(', ')}) VALUES (${placeholders})`;
  if (name === 'User') sql += ` ON CONFLICT (email) DO UPDATE SET ${updates}`;
  else if (name === 'Submission') sql += ` ON CONFLICT (id) DO NOTHING`;
  else sql += ` ON CONFLICT (id) DO UPDATE SET ${updates}`;
  sql += ' RETURNING *';
  const r = await pool.query(sql,values); return fromRow(name,r.rows[0]);
}

async function updateOne(name, filter, patch) {
  if (!dbReady) return memoryUpdateOne(name,filter,patch);
  const cols = columnMap[name]; const f = Object.entries(filter); const p = Object.entries(patch).filter(([k])=>cols[k]);
  if (!p.length) return findOne(name,filter);
  const values = [];
  const set = p.map(([k,v])=>{ values.push(toDbValue(name,k,v)); return `${cols[k]} = $${values.length}`; });
  const where = f.map(([k,v])=>{ values.push(toDbValue(name,k,v)); return `${cols[k]} = $${values.length}`; }).join(' AND ');
  const r = await pool.query(`UPDATE ${TABLES[name]} SET ${set.join(', ')} WHERE ${where} RETURNING *`,values);
  return r.rows[0] ? fromRow(name,r.rows[0]) : null;
}

function memoryFindOne(name, filter) { const key = memoryKey(name); return (memory[key]||[]).find(x=>Object.entries(filter).every(([k,v])=>String(x[k])===String(v))) || null; }
function memoryFindMany(name, filter, sort={createdAt:-1}, limit=100) { const key=memoryKey(name); return [...(memory[key]||[])].filter(x=>Object.entries(filter).every(([k,v])=>String(x[k])===String(v))).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,limit); }
function memorySave(name,obj) { const key=memoryKey(name); memory[key].unshift(obj); return obj; }
function memoryUpdateOne(name,filter,patch) { const x=memoryFindOne(name,filter); if(x) Object.assign(x,patch); return x; }
const memoryKey = {User:'users', Incident:'incidents', Feedback:'feedback', Forum:'forum', Submission:'submissions', Squad:'squads', Audit:'audit', Broadcast:'broadcasts', Threat:'threats', SkillProfile:'skillProfiles', SkillEvent:'skillEvents'};

async function audit(actor, action, target, meta={}) { await save('Audit',{id:id('AUD'),actor,action,target,meta,createdAt:new Date()}); }
async function getAdminCredential(email) {
  if (!dbReady || !pool) return null;
  const r = await pool.query('SELECT email,password_hash,token_version,updated_at FROM admin_credentials WHERE lower(email)=lower($1) LIMIT 1',[String(email||'')]);
  return r.rows[0] || null;
}
async function upsertAdminCredential(email,passwordHash,tokenVersion=0) {
  if (!dbReady || !pool) throw new Error('Database is required for administrator password changes.');
  const r = await pool.query(`INSERT INTO admin_credentials(email,password_hash,token_version,updated_at) VALUES($1,$2,$3,NOW()) ON CONFLICT(email) DO UPDATE SET password_hash=EXCLUDED.password_hash, token_version=EXCLUDED.token_version, updated_at=NOW() RETURNING email,password_hash,token_version,updated_at`,[String(email).toLowerCase(),passwordHash,tokenVersion]);
  return r.rows[0];
}
function sign(user, tokenVersion=0) { return jwt.sign({ sub: String(user.id), role: user.role, email: user.email, av: Number(tokenVersion)||0 }, JWT_SECRET, { expiresIn: '8h' }); }
function auth(requiredRole) {
  return async (req,res,next) => {
    try {
      const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')){ if(requiredRole==='admin') await recordThreat(req,'admin_endpoint_unauthorized','medium',{reason:'Missing or malformed admin authorization header'},{path:req.originalUrl}); return res.status(401).json({success:false,message:'Authentication required.'}); }
      const payload=jwt.verify(h.slice(7),JWT_SECRET); let user=null;
      if(payload.sub==='ENV_ADMIN' && payload.role==='admin') {
        const configuredEmail=process.env.ADMIN_EMAIL||'';
        const cred=await getAdminCredential(configuredEmail);
        if(cred && Number(payload.av||0)!==Number(cred.token_version||0)) {
          if(requiredRole==='admin') await recordThreat(req,'admin_session_revoked','high',{reason:'Administrator credential version changed'},{path:req.originalUrl});
          return res.status(401).json({success:false,message:'Administrator session was revoked. Please sign in again.'});
        }
        user={id:'ENV_ADMIN',name:'CyberShield Admin',email:cred?.email||configuredEmail,role:'admin'};
      } else user=await findOne('User',{id:payload.sub});
      if(!user){ if(requiredRole==='admin') await recordThreat(req,'admin_session_invalid','high',{reason:'JWT referenced a missing account'},{path:req.originalUrl}); return res.status(401).json({success:false,message:'Session is invalid.'}); }
      if(requiredRole && user.role!==requiredRole){ if(requiredRole==='admin') await recordThreat(req,'admin_privilege_denied','high',{reason:'Non-admin attempted admin endpoint'},{actor:user.id,path:req.originalUrl}); return res.status(403).json({success:false,message:'Insufficient permissions.'}); }
      req.user=user; next();
    } catch { if(requiredRole==='admin') await recordThreat(req,'admin_token_invalid','high',{reason:'Invalid or expired administrator token'},{path:req.originalUrl}); return res.status(401).json({success:false,message:'Session is invalid or expired.'}); }
  };
}
function id(prefix='CS') { return `${prefix}-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`; }
function riskScore(text='') { const s=text.toLowerCase(); let score=0; for(const [w,n] of [['password',30],['otp',25],['urgent',15],['money',20],['momo',25],['scholarship',15],['ransom',35],['malware',30],['link',10],['verify',10]]) if(s.includes(w)) score+=n; return Math.min(100,score); }
function networkZone(ip='') { if(!ip)return'unknown'; if(ip==='::1'||ip==='127.0.0.1')return'local-development'; if(ip.startsWith('10.')||ip.startsWith('192.168.')||/^172\.(1[6-9]|2\d|3[01])\./.test(ip))return'private-network'; return'public-network'; }
function threatSeverity(score){ return score>=85?'critical':score>=65?'high':score>=35?'medium':'low'; }
async function recordThreat(req, eventType, severity, details={}, evidence={}) {
  const event={id:id('THR'),eventType,severity,status:'open',sourceIp:req.ip||'',networkZone:networkZone(req.ip||''),userAgent:String(req.get('user-agent')||'').slice(0,500),path:req.originalUrl||req.path||'',actor:req.user?.id||'anonymous',details,evidence,createdAt:new Date(),updatedAt:new Date()};
  const saved=await save('Threat',event);
  await audit(event.actor,'security.threat.detected',saved.id,{eventType,severity,sourceIp:saved.sourceIp});
  io.emit('threat:new',{threat:saved}); wsBroadcast({type:'threat_new',threat:saved});
  return saved;
}
function securityScore(){
  const checks=[
    ['JWT secret',Boolean(JWT_SECRET&&JWT_SECRET.length>=32)],
    ['Helmet headers',true],['Rate limiting',true],['Admin RBAC',true],['Admin auto-lock',true],
    ['Database configured',Boolean(process.env.DATABASE_URL)],['HTTPS proxy awareness',true],
    ['Admin password configured',Boolean(process.env.ADMIN_PASSWORD)||dbReady],['CORS restricted',process.env.CORS_ORIGINS && process.env.CORS_ORIGINS!=='*'],
    ['MFA configured',Boolean(process.env.ADMIN_MFA_ENABLED==='true')],['CSA webhook configured',Boolean(process.env.CSA_WEBHOOK_URL)]
  ];
  const passed=checks.filter(x=>x[1]).length; return {score:Math.round(passed/checks.length*100),checks:checks.map(x=>({name:x[0],passed:x[1]}))};
}


const SKILLS = ['Threat Detection','Social Engineering','Networking','Web Security','Digital Forensics','Incident Response'];
const SKILL_TASKS = {
  'Threat Detection':['Analyze a suspicious login alert','Classify a phishing indicator','Triage a security notification'],
  'Social Engineering':['Identify manipulation tactics','Review a suspicious message','Choose a safe verification step'],
  'Networking':['Trace a safe network path','Interpret a DNS result','Identify a suspicious connection'],
  'Web Security':['Spot an unsafe web form','Review a browser security warning','Choose a secure web configuration'],
  'Digital Forensics':['Build an evidence timeline','Interpret a file-hash clue','Preserve incident evidence'],
  'Incident Response':['Prioritize a new incident','Choose containment steps','Build a response timeline']
};
function clamp(n,a=0,b=100){return Math.max(a,Math.min(b,Number(n)||0));}
function normalizeMastery(m={}){const out={};for(const k of SKILLS)out[k]=clamp(m[k]??0);return out;}
function nextAdaptiveSkill(m={}){const x=normalizeMastery(m);return SKILLS.slice().sort((a,b)=>x[a]-x[b])[0];}
async function getSkillProfile(userId){let p=await findOne('SkillProfile',{userId});if(!p){p={id:userId,userId,mastery:normalizeMastery(),totalAttempts:0,totalCompleted:0,updatedAt:new Date()};p=await save('SkillProfile',p);}p.mastery=normalizeMastery(p.mastery||{});return p;}

app.get('/api/health',(req,res)=>res.json({success:true,status:'healthy',database:dbReady?'supabase-postgresql':'temporary-memory',timestamp:new Date().toISOString()}));
app.get('/api/config',(req,res)=>res.json({success:true,features:{auth:true,incidents:true,forum:true,leaderboard:true,squads:true,competitions:true,realtime:true,audit:true,supabase:dbReady}}));

app.post('/api/auth/signup',authLimiter,async(req,res)=>{try{const{name,email,password,country='Ghana',school=null}=req.body||{};if(!name||!email||!password||password.length<8)return res.status(400).json({success:false,message:'Name, email and a password of at least 8 characters are required.'});const exists=await findOne('User',{email:email.toLowerCase()});if(exists)return res.status(409).json({success:false,message:'An account with that email already exists.'});const u={id:id('USR'),name,email:email.toLowerCase(),passwordHash:await bcrypt.hash(password,12),country,school,xp:0,role:'student',createdAt:new Date()};const user=await save('User',u);const safe={id:user.id,name:user.name,email:user.email,country:user.country,school:user.school,xp:user.xp,role:user.role};await audit(safe.id,'signup','user');res.status(201).json({success:true,token:sign(user),user:safe});}catch(e){console.error(e);res.status(500).json({success:false,message:'Unable to create account.'})}});
app.post('/api/auth/signin',authLimiter,async(req,res)=>{const{email,password}=req.body||{};if(!email||!password)return res.status(400).json({success:false,message:'Email and password are required.'});const user=await findOne('User',{email:email.toLowerCase()});if(!user||!(await bcrypt.compare(password,user.passwordHash)))return res.status(401).json({success:false,message:'Invalid email or password.'});const safe={id:user.id,name:user.name,email:user.email,country:user.country,school:user.school,xp:user.xp,role:user.role};res.json({success:true,token:sign(user),user:safe});});
app.get('/api/auth/me',auth(),async(req,res)=>res.json({success:true,user:{id:req.user.id,name:req.user.name,email:req.user.email,country:req.user.country,school:req.user.school,xp:req.user.xp,role:req.user.role}}));

app.get('/api/skills/me',auth(),async(req,res)=>{const p=await getSkillProfile(req.user.id);const next=nextAdaptiveSkill(p.mastery);res.json({success:true,skills:SKILLS.map(skill=>({skill,mastery:p.mastery[skill]||0})),next:{skill:next,tasks:SKILL_TASKS[next]},totalAttempts:p.totalAttempts,totalCompleted:p.totalCompleted});});
app.post('/api/skills/attempt',auth(),async(req,res)=>{const skill=String(req.body?.skill||'');if(!SKILLS.includes(skill))return res.status(400).json({success:false,message:'Unknown skill.'});const score=Math.round(clamp(req.body?.score));const duration=Math.max(0,Math.min(7200,Number(req.body?.durationSeconds)||0));const activity=String(req.body?.activity||'Adaptive challenge').slice(0,160);const p=await getSkillProfile(req.user.id);const old=clamp(p.mastery?.[skill]||0);const mastery=Math.round(old*0.65+score*0.35);const xpEarned=Math.max(5,Math.round(5+score/5));const updatedMastery={...normalizeMastery(p.mastery),[skill]:mastery};await updateOne('SkillProfile',{id:req.user.id},{mastery:updatedMastery,totalAttempts:(p.totalAttempts||0)+1,totalCompleted:(p.totalCompleted||0)+(score>=60?1:0),updatedAt:new Date()});await save('SkillEvent',{id:id('SKL'),userId:req.user.id,skill,activity,score,durationSeconds:duration,xpEarned,source:'adaptive',createdAt:new Date()});const user=await findOne('User',{id:req.user.id});await updateOne('User',{id:req.user.id},{xp:(user?.xp||0)+xpEarned});await audit(req.user.id,'skill.attempt',skill,{score,mastery,xpEarned,activity});const next=nextAdaptiveSkill(updatedMastery);res.json({success:true,mastery,skill,score,xpEarned,next:{skill:next,tasks:SKILL_TASKS[next]}});});


app.post('/api/incidents',auth(),async(req,res)=>{const{title,description,category='Uncategorized',severity,tags=[]}=req.body||{};if(!title||!description)return res.status(400).json({success:false,message:'Title and description are required.'});const score=riskScore(`${title} ${description}`);const autoSeverity=severity||(score>=70?'High':score>=35?'Medium':'Low');const incident={id:id(),title,description,category,severity:autoSeverity,status:'Pending',tags:Array.isArray(tags)?tags.slice(0,10):[],reporterId:req.user.id,reporterName:req.user.name,ip:req.ip,networkZone:networkZone(req.ip),riskScore:score,createdAt:new Date(),updatedAt:new Date()};const saved=await save('Incident',incident);await audit(req.user.id,'incident.created',saved.id,{severity:autoSeverity,riskScore:score});io.emit('incident:new',{incident:saved});wsBroadcast({type:'new_report',report:saved});res.status(201).json({success:true,incident:saved});});
app.get('/api/incidents',auth('admin'),async(req,res)=>{const incidents=await findMany('Incident');res.json({success:true,count:incidents.length,incidents});});
app.patch('/api/incidents/:id',auth('admin'),async(req,res)=>{const allowed=['status','severity','category','tags','assignedTo'];const patch={};for(const k of allowed)if(req.body[k]!==undefined)patch[k]=req.body[k];patch.updatedAt=new Date();const updated=await updateOne('Incident',{id:req.params.id},patch);if(!updated)return res.status(404).json({success:false,message:'Incident not found.'});await audit(req.user.id,'incident.updated',req.params.id,patch);io.emit('incident:updated',{incident:updated});res.json({success:true,incident:updated});});

app.post('/api/feedback',auth(),async(req,res)=>{const{category,message}=req.body||{};if(!message)return res.status(400).json({success:false,message:'Feedback message is required.'});const f=await save('Feedback',{id:id('FDB'),category:category||'General',message:String(message).slice(0,5000),userId:req.user.id,name:req.user.name,status:'new',adminReply:'',createdAt:new Date(),updatedAt:new Date()});io.emit('feedback:new',{feedback:f});res.status(201).json({success:true,feedback:f});});

app.get('/api/leaderboard',async(req,res)=>{const items=await findMany('User',{role:'student'},{xp:-1},100);res.json({success:true,items:items.map(x=>({name:x.name,country:x.country,school:x.school,xp:x.xp||0}))});});
app.get('/api/school-leagues',async(req,res)=>{const users=await findMany('User',{role:'student'}, {xp:-1},1000);const map={};for(const u of users){const k=u.school||'Independent Defenders';map[k] ||= {school:k,country:u.country||'Global',members:0,xp:0};map[k].members++;map[k].xp+=u.xp||0;}res.json({success:true,leagues:Object.values(map).sort((a,b)=>b.xp-a.xp)});});

app.get('/api/forum/posts',async(req,res)=>{const posts=await findMany('Forum');res.json({success:true,posts});});
app.post('/api/forum/posts',auth(),async(req,res)=>{const{title,body}=req.body||{};if(!title||!body)return res.status(400).json({success:false,message:'Title and body are required.'});const p=await save('Forum',{id:id('POST'),title:title.slice(0,120),body:body.slice(0,5000),userId:req.user.id,name:req.user.name,createdAt:new Date()});io.emit('forum:new',{post:p});res.status(201).json({success:true,post:p});});

app.get('/api/squads',async(req,res)=>{const squads=await findMany('Squad',{}, {xp:-1},100);res.json({success:true,squads});});
app.post('/api/squads',auth(),async(req,res)=>{const{name,school='',country=''}=req.body||{};if(!name)return res.status(400).json({success:false,message:'Squad name is required.'});const s=await save('Squad',{id:id('SQD'),name:name.slice(0,60),school:school.slice(0,100),country:country.slice(0,60),ownerId:req.user.id,members:1,xp:0,createdAt:new Date()});await audit(req.user.id,'squad.created',s.id);res.status(201).json({success:true,squad:s});});

app.post('/api/competitions/:type/submit',auth(),async(req,res)=>{const type=req.params.type;if(!['weekly','monthly'].includes(type))return res.status(404).json({success:false,message:'Competition not found.'});const answer=String(req.body?.answer||'').trim();if(answer.length<10)return res.status(400).json({success:false,message:'Answer is too short.'});const existing=await findOne('Submission',{type,userId:req.user.id});if(existing)return res.status(409).json({success:false,message:'You have already submitted this challenge.'});const total=await count('Submission',{type});const sub=await save('Submission',{id:id('SUB'),type,answer,userId:req.user.id,firstToSubmit:total===0,createdAt:new Date()});res.status(201).json({success:true,firstToSubmit:sub.firstToSubmit,submissionId:sub.id});});

app.get('/api/broadcasts',async(req,res)=>{const broadcasts=await findMany('Broadcast',{active:true});res.json({success:true,broadcasts});});
app.post('/api/admin/broadcast',auth('admin'),async(req,res)=>{const{message,severity='info'}=req.body||{};if(!message)return res.status(400).json({success:false,message:'Message required.'});const b=await save('Broadcast',{id:id('BC'),message,severity,active:true,createdAt:new Date()});await audit(req.user.id,'broadcast.created',b.id);io.emit('broadcast:new',{broadcast:b});res.status(201).json({success:true,broadcast:b});});
app.get('/api/admin/audit',auth('admin'),async(req,res)=>res.json({success:true,logs:await findMany('Audit',{}, {createdAt:-1},200)}));

app.get('/api/admin/reports',auth('admin'),async(req,res)=>{const reports=await findMany('Incident');res.json(reports.map(x=>({id:x.id,name:x.reporterName||'Anonymous',category:x.category,message:x.description,severity:x.severity,risk:x.riskScore||0,status:x.status,createdAt:x.createdAt,network:x.networkZone||'Backend logged',ip:x.ip||''})))});
app.patch('/api/admin/reports/:id',auth('admin'),async(req,res)=>{const allowed=['status','severity','category','tags','assignedTo','adminNote'];const patch={};for(const k of allowed)if(req.body[k]!==undefined)patch[k]=req.body[k];patch.updatedAt=new Date();const updated=await updateOne('Incident',{id:req.params.id},patch);if(!updated)return res.status(404).json({success:false,message:'Report not found.'});await audit(req.user.id,'admin.report.update',req.params.id,patch);io.emit('incident:updated',{incident:updated});wsBroadcast({type:'report_updated',report:updated});res.json({success:true,report:updated});});
app.get('/api/admin/feedback',auth('admin'),async(req,res)=>{const items=await findMany('Feedback');res.json(items.map(x=>({id:x.id,name:x.name||'Student',type:x.category,message:x.message,status:x.status||'new',createdAt:x.createdAt})))});
app.patch('/api/admin/feedback/:id',auth('admin'),async(req,res)=>{const patch={};if(req.body.status!==undefined)patch.status=String(req.body.status);if(req.body.adminReply!==undefined)patch.adminReply=String(req.body.adminReply).slice(0,5000);patch.updatedAt=new Date();if(patch.status)patch.reviewedAt=new Date();if(patch.adminReply)patch.repliedAt=new Date();const updated=await updateOne('Feedback',{id:req.params.id},patch);if(!updated)return res.status(404).json({success:false,message:'Feedback not found.'});await audit(req.user.id,'feedback.reviewed',req.params.id,patch);io.emit('feedback:updated',{feedback:updated});res.json({success:true,feedback:updated});});
app.get('/api/admin/students',auth('admin'),async(req,res)=>{const items=await findMany('User',{role:'student'},{xp:-1},500);res.json(items.map(x=>({id:x.id,name:x.name,email:x.email,school:x.school,level:x.level||'Student',xp:x.xp||0,status:'active'})));});
app.get('/api/admin/competitions',auth('admin'),async(req,res)=>{const types=['weekly','monthly'];const items=[];for(const type of types){const participants=await count('Submission',{type});items.push({id:type,name:type==='weekly'?'Weekly Cyber Challenge':'Monthly Cyber Challenge',scope:'Global',status:'active',participants});}res.json(items);});

app.get('/api/admin/skills/overview',auth('admin'),async(req,res)=>{const profiles=await findMany('SkillProfile',{}, {updatedAt:-1},1000);const events=await findMany('SkillEvent',{}, {createdAt:-1},5000);const users=await findMany('User',{role:'student'},{xp:-1},1000);const map={};for(const k of SKILLS)map[k]={skill:k,learners:0,attempts:0,avgMastery:0,avgScore:0};for(const p of profiles){const m=normalizeMastery(p.mastery||{});for(const k of SKILLS){if((m[k]||0)>0)map[k].learners++;map[k].avgMastery+=m[k]||0;}}for(const k of SKILLS)map[k].avgMastery=profiles.length?Math.round(map[k].avgMastery/profiles.length):0;for(const e of events){if(map[e.skill]){map[e.skill].attempts++;map[e.skill].avgScore+=Number(e.score)||0;}}for(const k of SKILLS)map[k].avgScore=map[k].attempts?Math.round(map[k].avgScore/map[k].attempts):0;const byCountry={},bySchool={};for(const u of users){const c=u.country||'Unknown',sc=u.school||'Independent Defenders';byCountry[c]=(byCountry[c]||0)+(u.xp||0);bySchool[sc]=(bySchool[sc]||0)+(u.xp||0);}res.json({success:true,students:users.length,profiles:profiles.length,skills:Object.values(map),topStudents:users.slice(0,10).map(u=>({name:u.name,school:u.school||'Independent Defenders',country:u.country||'Unknown',xp:u.xp||0})),countryXP:Object.entries(byCountry).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([country,xp])=>({country,xp})),schoolXP:Object.entries(bySchool).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([school,xp])=>({school,xp}))});});
app.get('/api/admin/security/overview',auth('admin'),async(req,res)=>{
  const base=securityScore();
  const threats=await findMany('Threat',{}, {createdAt:-1},100);
  const open=threats.filter(x=>!['resolved','closed'].includes(String(x.status||'').toLowerCase()));
  const high=threats.filter(x=>['high','critical'].includes(String(x.severity||'').toLowerCase()));
  const studentScore=Math.max(0,Math.min(100,base.score-(process.env.CORS_ORIGINS==='*'?5:0)));
  const adminScore=Math.max(0,Math.min(100,base.score-(process.env.ADMIN_MFA_ENABLED==='true'?0:10)));
  res.json({success:true,student:{score:studentScore,checks:base.checks},admin:{score:adminScore,checks:base.checks},threats:{total:threats.length,open:open.length,high:high.length},csa:{configured:Boolean(process.env.CSA_WEBHOOK_URL),reportUrl:'https://csa.gov.gh/report',email:'report@csa.gov.gh',phone:'292',whatsapp:'0501603111'}});
});
app.get('/api/admin/threats',auth('admin'),async(req,res)=>res.json({success:true,threats:await findMany('Threat',{}, {createdAt:-1},200)}));
app.patch('/api/admin/threats/:id',auth('admin'),async(req,res)=>{const allowed=['status','severity'];const patch={};for(const k of allowed)if(req.body[k]!==undefined)patch[k]=String(req.body[k]);patch.updatedAt=new Date();const updated=await updateOne('Threat',{id:req.params.id},patch);if(!updated)return res.status(404).json({success:false,message:'Threat not found.'});await audit(req.user.id,'security.threat.updated',req.params.id,patch);res.json({success:true,threat:updated});});
app.post('/api/admin/threats/:id/csa-report',auth('admin'),async(req,res)=>{
  const threat=await findOne('Threat',{id:req.params.id}); if(!threat)return res.status(404).json({success:false,message:'Threat not found.'});
  const report={incidentId:threat.id,eventType:threat.eventType,severity:threat.severity,detectedAt:threat.createdAt,sourceNetwork:threat.networkZone,sourceIp:threat.sourceIp,userAgent:threat.userAgent,path:threat.path,details:threat.details,evidence:threat.evidence,reportedBy:req.user.email||'CyberShield Admin'};
  let delivered=false, delivery='manual';
  if(process.env.CSA_WEBHOOK_URL){try{const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),7000);const rr=await fetch(process.env.CSA_WEBHOOK_URL,{method:'POST',headers:{'Content-Type':'application/json','X-CyberShield-Source':'CyberShield-Student'},body:JSON.stringify(report),signal:controller.signal});clearTimeout(timer);delivered=rr.ok;delivery=rr.ok?'webhook':'webhook_failed';}catch{delivery='webhook_failed';}}
  const status=delivered?'sent':'ready_for_manual_submission';
  const updated=await updateOne('Threat',{id:threat.id},{csaStatus:status,csaReference:`CSA-${Date.now()}`,updatedAt:new Date()});
  await audit(req.user.id,'security.csa.report',threat.id,{delivery,status});
  res.json({success:true,status,delivery,report,updated,official:{url:'https://csa.gov.gh/report',email:'report@csa.gov.gh',phone:'292',whatsapp:'0501603111'}});
});
app.get('/api/admin/session/validate',auth('admin'),async(req,res)=>res.json({success:true,valid:true}));
app.post('/api/admin/blacklist',auth('admin'),async(req,res)=>{await audit(req.user.id,'blacklist.opened','security');res.json({success:true,message:'Blacklist manager endpoint is protected and ready.'});});
app.post('/api/admin/login',authLimiter,async(req,res)=>{
  try {
    const{email,password}=req.body||{};
    if(!email||!password)return res.status(400).json({success:false,message:'Email and password are required.'});
    const normalized=String(email).trim().toLowerCase();
    const configured=String(process.env.ADMIN_EMAIL||'').trim().toLowerCase();
    let valid=false,tokenVersion=0,credential=null;
    if(normalized===configured) {
      credential=await getAdminCredential(normalized);
      if(credential) { valid=await bcrypt.compare(String(password),credential.password_hash); tokenVersion=Number(credential.token_version||0); }
      else valid=String(password)===String(process.env.ADMIN_PASSWORD||'');
    }
    if(!valid){await recordThreat(req,'admin_login_failed','medium',{reason:'Invalid administrator credentials'},{email:normalized,timestamp:new Date().toISOString()});return res.status(401).json({success:false,message:'Invalid admin credentials.'});}
    const admin={id:'ENV_ADMIN',name:'CyberShield Admin',email:normalized,role:'admin'};
    await audit('ENV_ADMIN','admin.login','admin',{ip:req.ip,userAgent:req.get('user-agent')||''});
    res.json({success:true,token:sign(admin,tokenVersion),user:admin});
  } catch(e) { console.error(e); res.status(500).json({success:false,message:'Unable to authenticate administrator.'}); }
});
app.post('/api/admin/password',auth('admin'),authLimiter,async(req,res)=>{
  try {
    const{currentPassword,newPassword,confirmPassword}=req.body||{};
    if(!currentPassword||!newPassword||!confirmPassword)return res.status(400).json({success:false,message:'Current password, new password and confirmation are required.'});
    if(newPassword!==confirmPassword)return res.status(400).json({success:false,message:'New passwords do not match.'});
    if(String(newPassword).length<12)return res.status(400).json({success:false,message:'New admin password must be at least 12 characters.'});
    if(String(newPassword)===String(currentPassword))return res.status(400).json({success:false,message:'New password must be different from the current password.'});
    if(!dbReady)return res.status(503).json({success:false,message:'Administrator password changes require the configured Supabase database.'});
    const email=String(req.user.email||process.env.ADMIN_EMAIL||'').toLowerCase();
    const credential=await getAdminCredential(email);
    let currentValid=false,version=0;
    if(credential){ currentValid=await bcrypt.compare(String(currentPassword),credential.password_hash); version=Number(credential.token_version||0); }
    else { currentValid=String(currentPassword)===String(process.env.ADMIN_PASSWORD||''); version=0; }
    if(!currentValid){await recordThreat(req,'admin_password_change_failed','high',{reason:'Current administrator password was incorrect'},{email});return res.status(401).json({success:false,message:'Current password is incorrect.'});}
    const hash=await bcrypt.hash(String(newPassword),12);
    const nextVersion=version+1;
    await upsertAdminCredential(email,hash,nextVersion);
    await audit(req.user.id,'admin.password.changed','admin',{email,tokenVersion:nextVersion});
    const admin={id:'ENV_ADMIN',name:'CyberShield Admin',email,role:'admin'};
    res.json({success:true,message:'Administrator password changed successfully. Other admin sessions have been revoked.',token:sign(admin,nextVersion),user:admin});
  } catch(e) { console.error(e); res.status(500).json({success:false,message:'Unable to change administrator password.'}); }
});

io.on('connection',socket=>socket.emit('connected',{service:'CyberShield realtime',time:new Date().toISOString()}));
app.use(express.static(path.join(__dirname,'public'),{index:'index.html'}));
app.get('/admin',(req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('/admin.html',(req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('*',(req,res)=>{if(req.path.startsWith('/api/'))return res.status(404).json({success:false,message:'CyberShield API route not found.'});if(req.path==='/ws')return res.status(426).send('WebSocket upgrade required.');res.sendFile(path.join(__dirname,'public','index.html'));});
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({success:false,message:'Internal server error.'});});
server.listen(PORT,()=>console.log(`CyberShield API listening on port ${PORT}`));
