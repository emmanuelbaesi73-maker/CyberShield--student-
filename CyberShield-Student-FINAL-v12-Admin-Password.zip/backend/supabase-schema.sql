-- CyberShield Student - Supabase PostgreSQL schema
-- The backend also creates these tables automatically on startup.
CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, country TEXT DEFAULT 'Ghana', school TEXT, xp INTEGER DEFAULT 0, role TEXT DEFAULT 'student', created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS admin_credentials (email TEXT PRIMARY KEY, password_hash TEXT NOT NULL, token_version INTEGER DEFAULT 0, updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS incidents (id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL, category TEXT, severity TEXT, status TEXT DEFAULT 'Pending', tags JSONB DEFAULT '[]'::jsonb, reporter_id TEXT, reporter_name TEXT, ip TEXT, network_zone TEXT, risk_score INTEGER DEFAULT 0, assigned_to TEXT, admin_note TEXT, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS feedback (id TEXT PRIMARY KEY, category TEXT, message TEXT NOT NULL, user_id TEXT, name TEXT, status TEXT DEFAULT 'new', admin_reply TEXT DEFAULT '', reviewed_at TIMESTAMPTZ, replied_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS forum_posts (id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, user_id TEXT, name TEXT, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS submissions (id TEXT PRIMARY KEY, type TEXT NOT NULL, answer TEXT NOT NULL, user_id TEXT NOT NULL, first_to_submit BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE UNIQUE INDEX IF NOT EXISTS submissions_user_type_idx ON submissions(type, user_id);
CREATE TABLE IF NOT EXISTS squads (id TEXT PRIMARY KEY, name TEXT NOT NULL, school TEXT DEFAULT '', country TEXT DEFAULT '', owner_id TEXT, members INTEGER DEFAULT 1, xp INTEGER DEFAULT 0, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS audit_logs (id BIGSERIAL PRIMARY KEY, actor TEXT, action TEXT, target TEXT, meta JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS broadcasts (id TEXT PRIMARY KEY, message TEXT NOT NULL, severity TEXT DEFAULT 'info', active BOOLEAN DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT NOW());

CREATE TABLE IF NOT EXISTS threat_events (id TEXT PRIMARY KEY, event_type TEXT NOT NULL, severity TEXT NOT NULL, status TEXT DEFAULT 'open', source_ip TEXT, network_zone TEXT, user_agent TEXT, path TEXT, actor TEXT, details JSONB DEFAULT '{}'::jsonb, evidence JSONB DEFAULT '{}'::jsonb, csa_status TEXT DEFAULT 'not_reported', csa_reference TEXT, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE INDEX IF NOT EXISTS threat_created_idx ON threat_events(created_at DESC);
CREATE INDEX IF NOT EXISTS threat_status_idx ON threat_events(status);


CREATE TABLE IF NOT EXISTS skill_profiles (id TEXT PRIMARY KEY, user_id TEXT NOT NULL UNIQUE, mastery JSONB DEFAULT '{}'::jsonb, total_attempts INTEGER DEFAULT 0, total_completed INTEGER DEFAULT 0, updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS skill_events (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, skill TEXT NOT NULL, activity TEXT NOT NULL, score INTEGER NOT NULL DEFAULT 0, duration_seconds INTEGER DEFAULT 0, xp_earned INTEGER DEFAULT 0, source TEXT DEFAULT 'adaptive', created_at TIMESTAMPTZ DEFAULT NOW());
CREATE INDEX IF NOT EXISTS skill_events_user_idx ON skill_events(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS skill_events_skill_idx ON skill_events(skill, created_at DESC);
