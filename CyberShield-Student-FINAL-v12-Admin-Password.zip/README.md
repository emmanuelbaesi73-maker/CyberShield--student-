# CyberShield Student

CyberShield Student is a student-focused cybersecurity learning, reporting, competition, community and administration platform.

## Current architecture

- **Frontend:** HTML/CSS/JavaScript
- **Backend:** Node.js + Express
- **Database:** Supabase PostgreSQL (Free plan compatible)
- **Authentication:** bcrypt password hashing + JWT sessions
- **Realtime:** Socket.IO + WebSocket endpoint
- **Security:** Helmet, CORS, rate limiting and protected admin routes
- **Deployment:** Render-compatible Node web service
- **License:** MIT License

## Main features

### Student Platform
- Cybersecurity Academy
- Missions and learning activities
- Security Center
- Incident reporting with automated risk scoring
- Weekly and monthly competitions
- Worldwide / regional / school competition concepts
- Leaderboards and school leagues
- Forum/community posts
- Squads
- Student feedback
- Profile and progress data
- Video/content sections

### Admin Platform
- Separate admin interface
- Live incident queue
- Incident status/severity/category management
- Risk scoring
- Admin notes and assignment fields
- Student feedback review/reply workflow
- Student and competition views
- Audit log
- Broadcasts
- Protected admin login
- Realtime events
- WebSocket integration hooks

## Project structure

```text
CyberShield-Student/
├── README.md
├── LICENSE
├── .gitignore
├── admin.html
├── render.yaml
└── backend/
    ├── server.js
    ├── package.json
    ├── .env.example
    ├── .gitignore
    ├── supabase-schema.sql
    └── public/
        ├── index.html
        ├── admin.html
        ├── manifest.webmanifest
        └── service-worker.js
```

## Local setup

### 1. Install Node.js

Use Node.js 18 or newer.

### 2. Install backend dependencies

```bash
cd backend
npm install
```

### 3. Create environment variables

Copy `.env.example` to `.env` and set:

```env
PORT=3000
JWT_SECRET=replace-with-a-random-secret-at-least-32-characters-long
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=replace-with-a-strong-admin-password
DATABASE_URL=postgresql://postgres:YOUR_DATABASE_PASSWORD@YOUR_PROJECT_HOST:5432/postgres?sslmode=require
DATABASE_SSL=true
CORS_ORIGINS=*
DB_POOL_MAX=5
```

Never commit `.env`.

### 4. Supabase database

Create a Supabase project on the **Free** plan. The backend automatically creates the CyberShield tables when it connects for the first time.

A manual SQL script is also included at:

```text
backend/supabase-schema.sql
```

If you use the SQL Editor, paste that file and run it once. Otherwise, the backend's startup initialization can create the tables automatically.

### 5. Start CyberShield

```bash
npm start
```

Open:

```text
http://localhost:3000
```

Admin:

```text
http://localhost:3000/admin
```

Health check:

```text
http://localhost:3000/api/health
```

A connected database should return:

```json
{
  "success": true,
  "status": "healthy",
  "database": "supabase-postgresql"
}
```

## Supabase Free plan

CyberShield is designed for a no-cost student deployment using Supabase's Free plan. Check Supabase's current pricing and usage limits before deployment because plan limits can change. Free projects may pause after inactivity, so the platform should be checked before demonstrations or competitions.

## Render deployment

The included `render.yaml` configures a Node web service using the `backend` directory.

Recommended Render settings:

- **Root Directory:** `backend`
- **Build Command:** `npm install`
- **Start Command:** `npm start`
- **Health Check:** `/api/health`

Set these environment variables in Render:

```text
JWT_SECRET
ADMIN_EMAIL
ADMIN_PASSWORD
DATABASE_URL
DATABASE_SSL=true
CORS_ORIGINS=*
```

Do not put passwords, database connection strings or JWT secrets in GitHub source files.

## GitHub

The repository can be public for project showcasing, but secrets must remain private in environment variables.

Never commit:

- `.env`
- MongoDB connection strings
- Supabase database passwords
- JWT secrets
- Admin passwords
- API keys
- private tokens

## Important security note

The browser is not trusted for authorization. Student/admin authorization is enforced by the backend using JWT verification and role checks. The admin password is read from an environment variable and is not stored in frontend JavaScript.

## Database migration note

This version uses PostgreSQL through Supabase instead of MongoDB/Mongoose. The API routes remain the same so the existing CyberShield frontend can continue using the `/api` interface.

## Status

**CyberShield Student — Supabase migration version**

The next deployment step is to create the Supabase project and copy its PostgreSQL connection string into the backend environment variables. No database password or JWT secret belongs in GitHub.

## Administrator password management

The Admin Platform now supports changing the administrator password from **Settings → Administrator password**.

- The current password must be verified before a change.
- New passwords must be at least 12 characters and must be confirmed.
- Passwords are stored as bcrypt hashes in the Supabase `admin_credentials` table; the plaintext password is never stored.
- After a successful change, the server revokes older administrator JWT sessions and returns a fresh session token to the current browser.
- `ADMIN_EMAIL` and `ADMIN_PASSWORD` remain the bootstrap credentials for the administrator. Once a database-backed admin credential exists, that stored credential is used for subsequent admin logins.
- Keep the Render environment variables configured so the administrator can recover/bootstrap access if the admin credential table is ever reset.

## Security Center & Threat Response

The Admin Platform now includes a server-backed Security Center and Threat Response workflow. It can record failed administrator authentication events and other protected-endpoint security signals, preserve technical evidence, show an incident timeline, track containment status, and prepare a report for Ghana's Cyber Security Authority / CERT-GH.

The Admin Platform does **not** attempt to hack back or identify a person from an IP address alone. Security metadata is restricted to authorized administrators and should be retained only as needed for legitimate security purposes.

### CSA / CERT-GH reporting

The official CSA incident reporting page is `https://csa.gov.gh/report`. The CSA currently lists `report@csa.gov.gh`, call/SMS `292`, and WhatsApp `0501603111` as reporting contacts. CyberShield can open the official reporting page and copy a structured incident report. An optional `CSA_WEBHOOK_URL` can be configured if an authorized organizational integration is later established; without it, CyberShield does not pretend an external notification was sent.

### Security posture

The Admin Security Center shows configuration-based checks for both the Student Platform and Admin Platform. These are operational indicators, not a penetration-test certificate or guarantee that the application is unhackable.


## V11 — Skill DNA + Adaptive Learning

- Student Skill DNA tracks six defensive cybersecurity skills.
- Adaptive recommendations select the lowest-mastery skill for the next task.
- Authenticated skill attempts update mastery and award XP server-side.
- Admin Skill Analytics shows learner counts, attempts, average mastery, average score, student XP and school XP.
- Skill data is stored in Supabase PostgreSQL when `DATABASE_URL` is configured and uses temporary memory storage for local testing.
- Skill mastery is separate from competitive rankings; the adaptive engine does not manufacture leaderboard positions.
