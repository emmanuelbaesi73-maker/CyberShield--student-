require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const { Server } = require('socket.io');
const { WebSocketServer } = require('ws');
const crypto = require('crypto');

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  throw new Error('JWT_SECRET must be set and at least 32 characters long.');
}
const origins = (process.env.CORS_ORIGINS || '*').split(',').map(x => x.trim()).filter(Boolean);

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: origins.includes('*') ? true : origins, credentials: true }));
app.use(express.json({ limit: '200kb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 25, standardHeaders: true, legacyHeaders: false });

const io = new Server(server, { cors: { origin: origins.includes('*') ? '*' : origins } });
const wss = new WebSocketServer({ server, path: '/ws' });
const wsBroadcast = (payload) => { const msg=JSON.stringify(payload); wss.clients.forEach(c=>{ if(c.readyState===1) c.send(msg); }); };
wss.on('connection', ws => ws.send(JSON.stringify({type:'connected',service:'CyberShield realtime',time:new Date().toISOString()})));

const memory = { users: [], incidents: [], feedback: [], forum: [], submissions: [], squads: [], audit: [], broadcasts: [] };
const memoryKey = {User:'users', Incident:'incidents', Feedback:'feedback', Forum:'forum', Submission:'submissions', Squad:'squads', Audit:'audit', Broadcast:'broadcasts'};

const schemas = {};
if (mongoose) {
  schemas.User = mongoose.model('User', new mongoose.Schema({
    name: { type: String, required: true, trim: true, maxlength: 40 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true }, country: { type: String, default: 'Ghana' },
    school: { type: String, default: null }, xp: { type: Number, default: 0 },
    role: { type: String, enum: ['student','admin'], default: 'student' },
    createdAt: { type: Date, default: Date.now }
  }));
  schemas.Incident = mongoose.model('Incident', new mongoose.Schema({
    id: { type: String, unique: true }, title: String, description: String, category: String,
    severity: String, status: { type: String, default: 'Pending' }, tags: [String],
    reporterId: String, reporterName: String, ip: String, networkZone: String, riskScore: Number, assignedTo: String, adminNote: String, createdAt: { type: Date, default: Date.now }, updatedAt: { type: Date, default: Date.now }
  }));
  schemas.Feedback = mongoose.model('Feedback', new mongoose.Schema({ id: {type:String, unique:true}, category: String, message: String, userId: String, name: String, status: {type:String, default:'new'}, adminReply: {type:String, default:''}, reviewedAt: Date, repliedAt: Date, createdAt: { type: Date, default: Date.now }, updatedAt: {type:Date, default:Date.now} }));
  schemas.Forum = mongoose.model('Forum', new mongoose.Schema({ title: String, body: String, userId: String, name: String, createdAt: { type: Date, default: Date.now } }));
  schemas.Submission = mongoose.model('Submission', new mongoose.Schema({ type: String, answer: String, userId: String, firstToSubmit: Boolean, createdAt: { type: Date, default: Date.now } }));
  schemas.Squad = mongoose.model('Squad', new mongoose.Schema({ name: String, school: String, country: String, ownerId: String, members: { type: Number, default: 1 }, xp: { type: Number, default: 0 }, createdAt: { type: Date, default: Date.now } }));
  schemas.Audit = mongoose.model('Audit', new mongoose.Schema({ actor: String, action: String, target: String, meta: Object, createdAt: { type: Date, default: Date.now } }));
  schemas.Broadcast = mongoose.model('Broadcast', new mongoose.Schema({ message: String, severity: String, active: Boolean, createdAt: { type: Date, default: Date.now } }));
}

let dbReady = false;
async function connectDb() {
  if (!process.env.MONGODB_URI) return;
  try { await mongoose.connect(process.env.MONGODB_URI); dbReady = true; console.log('MongoDB connected'); }
  catch (e) { console.error('MongoDB connection failed; using temporary memory storage:', e.message); }
}
connectDb();

const store = (name) => dbReady ? schemas[name] : null;
async function findMany(name, filter = {}, sort = { createdAt: -1 }, limit = 100) {
  const M = store(name); if (M) return M.find(filter).sort(sort).limit(limit).lean();
  return [...(memory[memoryKey[name]] || [])].filter(x => Object.entries(filter).every(([k,v]) => x[k] === v)).sort((a,b) => new Date(b.createdAt)-new Date(a.createdAt)).slice(0,limit);
}
async function save(name, obj) {
  const M = store(name); if (M) return new M(obj).save().then(x => x.toObject());
  const key = memoryKey[name]; if (!memory[key]) memory[key] = []; memory[key].unshift(obj); return obj;
}
async function audit(actor, action, target, meta={}) { await save('Audit', { actor, action, target, meta, createdAt: new Date() }); }

function sign(user) { return jwt.sign({ sub: String(user._id || user.id), role: user.role, email: user.email }, JWT_SECRET, { expiresIn: '8h' }); }
function auth(requiredRole) {
  return async (req,res,next) => {
    try {
      const h = req.headers.authorization || ''; if (!h.startsWith('Bearer ')) return res.status(401).json({success:false,message:'Authentication required.'});
      const payload = jwt.verify(h.slice(7), JWT_SECRET); let user = null;
      if (payload.sub === 'ENV_ADMIN' && payload.role === 'admin') {
        user = {id:'ENV_ADMIN',name:'CyberShield Admin',email:process.env.ADMIN_EMAIL,role:'admin'};
      } else {
        const M = store('User');
        if (M) user = await M.findOne({$or:[{_id:payload.sub},{id:payload.sub}]}).lean();
        else user = memory.users.find(x => String(x.id) === String(payload.sub));
      }
      if (!user) return res.status(401).json({success:false,message:'Session is invalid.'});
      if (requiredRole && user.role !== requiredRole) return res.status(403).json({success:false,message:'Insufficient permissions.'});
      req.user = user; next();
    } catch { return res.status(401).json({success:false,message:'Session is invalid or expired.'}); }
  };
}
function id(prefix='CS') { return `${prefix}-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`; }
function riskScore(text='') { const s=text.toLowerCase(); let score=0; for (const [w,n] of [['password',30],['otp',25],['urgent',15],['money',20],['momo',25],['scholarship',15],['ransom',35],['malware',30],['link',10],['verify',10]]) if(s.includes(w)) score+=n; return Math.min(100,score); }
function networkZone(ip='') { if (!ip) return 'unknown'; if (ip==='::1' || ip==='127.0.0.1') return 'local-development'; if (ip.startsWith('10.') || ip.startsWith('192.168.') || /^172\.(1[6-9]|2\d|3[01])\./.test(ip)) return 'private-network'; return 'public-network'; }

app.get('/api/health', (req,res) => res.json({success:true,status:'healthy',database:dbReady?'connected':'temporary-memory',timestamp:new Date().toISOString()}));
app.get('/api/config', (req,res) => res.json({success:true,features:{auth:true,incidents:true,forum:true,leaderboard:true,squads:true,competitions:true,realtime:true,audit:true,mongodb:dbReady}}));

app.post('/api/auth/signup', authLimiter, async (req,res) => {
  try {
    const {name,email,password,country='Ghana',school=null} = req.body || {};
    if (!name || !email || !password || password.length < 8) return res.status(400).json({success:false,message:'Name, email and a password of at least 8 characters are required.'});
    const exists = store('User') ? await schemas.User.findOne({email:email.toLowerCase()}) : memory.users.find(x=>x.email===email.toLowerCase());
    if (exists) return res.status(409).json({success:false,message:'An account with that email already exists.'});
    const u={id:id('USR'),name,email:email.toLowerCase(),passwordHash:await bcrypt.hash(password,12),country,school,xp:0,role:'student',createdAt:new Date()};
    const user=await save('User',u); const safe={id:user.id||user._id,name:user.name,email:user.email,country:user.country,school:user.school,xp:user.xp,role:user.role};
    await audit(safe.id,'signup','user'); res.status(201).json({success:true,token:sign({...user,id:user.id||user._id}),user:safe});
  } catch(e){res.status(500).json({success:false,message:'Unable to create account.'})}
});

app.post('/api/auth/signin', authLimiter, async (req,res) => {
  const {email,password}=req.body||{}; if(!email||!password)return res.status(400).json({success:false,message:'Email and password are required.'});
  let user=store('User') ? await schemas.User.findOne({email:email.toLowerCase()}) : memory.users.find(x=>x.email===email.toLowerCase());
  if(!user || !(await bcrypt.compare(password,user.passwordHash))) return res.status(401).json({success:false,message:'Invalid email or password.'});
  const safe={id:user.id||user._id,name:user.name,email:user.email,country:user.country,school:user.school,xp:user.xp,role:user.role};
  res.json({success:true,token:sign({...user,id:user.id||user._id}),user:safe});
});
app.get('/api/auth/me',auth(),async(req,res)=>res.json({success:true,user:{id:req.user.id||req.user._id,name:req.user.name,email:req.user.email,country:req.user.country,school:req.user.school,xp:req.user.xp,role:req.user.role}}));

app.post('/api/incidents', auth(), async (req,res)=>{
  const {title,description,category='Uncategorized',severity,tags=[]}=req.body||{};
  if(!title||!description)return res.status(400).json({success:false,message:'Title and description are required.'});
  const score=riskScore(`${title} ${description}`); const autoSeverity=severity || (score>=70?'High':score>=35?'Medium':'Low');
  const incident={id:id(),title,description,category,severity:autoSeverity,status:'Pending',tags:Array.isArray(tags)?tags.slice(0,10):[],reporterId:String(req.user.id||req.user._id),reporterName:req.user.name,ip:req.ip,networkZone:networkZone(req.ip),riskScore:score,createdAt:new Date(),updatedAt:new Date()};
  const saved=await save('Incident',incident); await audit(String(req.user.id||req.user._id),'incident.created',saved.id,{severity:autoSeverity,riskScore:score});
  io.emit('incident:new',{incident:saved}); wsBroadcast({type:'new_report',report:saved}); res.status(201).json({success:true,incident:saved});
});
app.get('/api/incidents',auth('admin'),async(req,res)=>{const incidents=await findMany('Incident');res.json({success:true,count:incidents.length,incidents});});
app.patch('/api/incidents/:id',auth('admin'),async(req,res)=>{const allowed=['status','severity','category','tags','assignedTo']; const patch={};for(const k of allowed)if(req.body[k]!==undefined)patch[k]=req.body[k];patch.updatedAt=new Date();let updated;
  if(store('Incident'))updated=await schemas.Incident.findOneAndUpdate({id:req.params.id},patch,{new:true}).lean(); else {const i=memory.incidents.find(x=>x.id===req.params.id);if(i)Object.assign(i,patch);updated=i;}
  if(!updated)return res.status(404).json({success:false,message:'Incident not found.'}); await audit(String(req.user.id||req.user._id),'incident.updated',req.params.id,patch);io.emit('incident:updated',{incident:updated});res.json({success:true,incident:updated});
});

app.post('/api/feedback',auth(),async(req,res)=>{const {category,message}=req.body||{};if(!message)return res.status(400).json({success:false,message:'Feedback message is required.'});const f=await save('Feedback',{id:id('FDB'),category:category||'General',message:String(message).slice(0,5000),userId:String(req.user.id||req.user._id),name:req.user.name,status:'new',adminReply:'',createdAt:new Date(),updatedAt:new Date()});io.emit('feedback:new',{feedback:f});res.status(201).json({success:true,feedback:f});});

app.get('/api/leaderboard',async(req,res)=>{const M=store('User');let items=M?await M.find({role:'student'}).sort({xp:-1}).limit(100).lean():memory.users.filter(x=>x.role==='student').sort((a,b)=>b.xp-a.xp).slice(0,100);res.json({success:true,items:items.map(x=>({name:x.name,country:x.country,school:x.school,xp:x.xp||0}))});});
app.get('/api/school-leagues',async(req,res)=>{const M=store('User');let users=M?await M.find({role:'student'}).lean():memory.users.filter(x=>x.role==='student');const map={};for(const u of users){const k=u.school||'Independent Defenders';map[k] ||= {school:k,country:u.country||'Global',members:0,xp:0};map[k].members++;map[k].xp+=u.xp||0;}res.json({success:true,leagues:Object.values(map).sort((a,b)=>b.xp-a.xp)});});

app.get('/api/forum/posts',async(req,res)=>{const posts=await findMany('Forum');res.json({success:true,posts});});
app.post('/api/forum/posts',auth(),async(req,res)=>{const {title,body}=req.body||{};if(!title||!body)return res.status(400).json({success:false,message:'Title and body are required.'});const p=await save('Forum',{id:id('POST'),title:title.slice(0,120),body:body.slice(0,5000),userId:String(req.user.id||req.user._id),name:req.user.name,createdAt:new Date()});io.emit('forum:new',{post:p});res.status(201).json({success:true,post:p});});

app.get('/api/squads',async(req,res)=>{const squads=await findMany('Squad',{}, {xp:-1},100);res.json({success:true,squads});});
app.post('/api/squads',auth(),async(req,res)=>{const {name,school='',country=''}=req.body||{};if(!name)return res.status(400).json({success:false,message:'Squad name is required.'});const s=await save('Squad',{id:id('SQD'),name:name.slice(0,60),school:school.slice(0,100),country:country.slice(0,60),ownerId:String(req.user.id||req.user._id),members:1,xp:0,createdAt:new Date()});await audit(String(req.user.id||req.user._id),'squad.created',s.id);res.status(201).json({success:true,squad:s});});

app.post('/api/competitions/:type/submit',auth(),async(req,res)=>{const type=req.params.type;if(!['weekly','monthly'].includes(type))return res.status(404).json({success:false,message:'Competition not found.'});const answer=String(req.body?.answer||'').trim();if(answer.length<10)return res.status(400).json({success:false,message:'Answer is too short.'});const existing=store('Submission')?await schemas.Submission.findOne({type,userId:String(req.user.id||req.user._id)}):memory.submissions.find(x=>x.type===type&&x.userId===String(req.user.id||req.user._id));if(existing)return res.status(409).json({success:false,message:'You have already submitted this challenge.'});const count=store('Submission')?await schemas.Submission.countDocuments({type}):memory.submissions.filter(x=>x.type===type).length;const sub=await save('Submission',{id:id('SUB'),type,answer,userId:String(req.user.id||req.user._id),firstToSubmit:count===0,createdAt:new Date()});res.status(201).json({success:true,firstToSubmit:sub.firstToSubmit,submissionId:sub.id});});

app.get('/api/broadcasts',async(req,res)=>{const broadcasts=await findMany('Broadcast',{active:true});res.json({success:true,broadcasts});});
app.post('/api/admin/broadcast',auth('admin'),async(req,res)=>{const {message,severity='info'}=req.body||{};if(!message)return res.status(400).json({success:false,message:'Message required.'});const b=await save('Broadcast',{id:id('BC'),message,severity,active:true,createdAt:new Date()});await audit(String(req.user.id||req.user._id),'broadcast.created',b.id);io.emit('broadcast:new',{broadcast:b});res.status(201).json({success:true,broadcast:b});});
app.get('/api/admin/audit',auth('admin'),async(req,res)=>res.json({success:true,logs:await findMany('Audit',{}, {createdAt:-1},200)}));

app.get('/api/admin/reports',auth('admin'),async(req,res)=>{const reports=await findMany('Incident');res.json(reports.map(x=>({id:x.id,name:x.reporterName||'Anonymous',category:x.category,message:x.description,severity:x.severity,risk:x.riskScore||0,status:x.status,createdAt:x.createdAt,network:x.networkZone||'Backend logged',ip:x.ip||''})));});
app.patch('/api/admin/reports/:id',auth('admin'),async(req,res)=>{const allowed=['status','severity','category','tags','assignedTo','adminNote'];const patch={};for(const k of allowed)if(req.body[k]!==undefined)patch[k]=req.body[k];patch.updatedAt=new Date();let updated;if(store('Incident'))updated=await schemas.Incident.findOneAndUpdate({id:req.params.id},patch,{new:true}).lean();else{const x=memory.incidents.find(i=>i.id===req.params.id);if(x)Object.assign(x,patch);updated=x;}if(!updated)return res.status(404).json({success:false,message:'Report not found.'});await audit(String(req.user.id||req.user._id),'admin.report.update',req.params.id,patch);io.emit('incident:updated',{incident:updated});wsBroadcast({type:'report_updated',report:updated});res.json({success:true,report:updated});});
app.get('/api/admin/feedback',auth('admin'),async(req,res)=>{const items=await findMany('Feedback');res.json(items.map(x=>({id:x._id||x.id,name:x.name||'Student',type:x.category,message:x.message,status:x.status||'new',createdAt:x.createdAt})));});
app.patch('/api/admin/feedback/:id',auth('admin'),async(req,res)=>{const patch={};if(req.body.status!==undefined)patch.status=String(req.body.status);if(req.body.adminReply!==undefined)patch.adminReply=String(req.body.adminReply).slice(0,5000);patch.updatedAt=new Date();if(patch.status)patch.reviewedAt=new Date();if(patch.adminReply)patch.repliedAt=new Date();let updated;if(store('Feedback'))updated=await schemas.Feedback.findOneAndUpdate({$or:[{id:req.params.id},{_id:req.params.id}]},patch,{new:true}).lean();else{updated=memory.feedback.find(x=>String(x.id)===String(req.params.id));if(updated)Object.assign(updated,patch);}if(!updated)return res.status(404).json({success:false,message:'Feedback not found.'});await audit(String(req.user.id||req.user._id),'feedback.reviewed',req.params.id,patch);io.emit('feedback:updated',{feedback:updated});res.json({success:true,feedback:updated});});
app.get('/api/admin/students',auth('admin'),async(req,res)=>{const M=store('User');const items=M?await M.find({role:'student'}).sort({xp:-1}).limit(500).lean():memory.users.filter(x=>x.role==='student');res.json(items.map(x=>({id:x._id||x.id,name:x.name,email:x.email,school:x.school,level:x.level||'Student',xp:x.xp||0,status:'active'})));});
app.get('/api/admin/competitions',auth('admin'),async(req,res)=>{const types=['weekly','monthly'];const items=[];for(const type of types){const M=store('Submission');const participants=M?await M.countDocuments({type}):memory.submissions.filter(x=>x.type===type).length;items.push({id:type,name:type==='weekly'?'Weekly Cyber Challenge':'Monthly Cyber Challenge',scope:'Global',status:'active',participants});}res.json(items);});
app.get('/api/admin/session/validate',auth('admin'),async(req,res)=>res.json({success:true,valid:true}));
app.post('/api/admin/blacklist',auth('admin'),async(req,res)=>{await audit(String(req.user.id||req.user._id),'blacklist.opened','security');res.json({success:true,message:'Blacklist manager endpoint is protected and ready.'});});
app.post('/api/admin/login',authLimiter,async(req,res)=>{const {email,password}=req.body||{};if(!email||!password)return res.status(400).json({success:false,message:'Email and password are required.'});if(email.toLowerCase()!==String(process.env.ADMIN_EMAIL||'').toLowerCase()||password!==process.env.ADMIN_PASSWORD)return res.status(401).json({success:false,message:'Invalid admin credentials.'});const admin={id:'ENV_ADMIN',name:'CyberShield Admin',email,role:'admin'};res.json({success:true,token:sign(admin),user:admin});});

io.on('connection',socket=>{socket.emit('connected',{service:'CyberShield realtime',time:new Date().toISOString()});});

const path = require('path');
app.use(express.static(path.join(__dirname, 'public'), { index: 'index.html' }));
app.get('/admin', (req,res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/admin.html', (req,res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('*', (req,res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({success:false,message:'CyberShield API route not found.'});
  if (req.path === '/ws') return res.status(426).send('WebSocket upgrade required.');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use((req,res)=>res.status(404).json({success:false,message:'CyberShield API route not found.'}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({success:false,message:'Internal server error.'});});

server.listen(PORT,()=>console.log(`CyberShield API listening on port ${PORT}`));
