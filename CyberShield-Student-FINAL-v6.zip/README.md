# CyberShield Student

CyberShield Student is a student cybersecurity learning and competition platform with a same-origin Express API and a separate admin platform.

## Package structure
- `backend/public/index.html` — Student Platform
- `backend/public/admin.html` — Admin Platform served at `/admin`
- `backend/server.js` — Express API, auth, realtime, admin endpoints and static hosting
- `backend/package.json` — Node dependencies and start command
- `backend/.env.example` — required environment variable template
- `render.yaml` — Render deployment configuration

## Local run
1. Open `backend` in a terminal.
2. Copy `.env.example` to `.env`.
3. Set `JWT_SECRET` to a random value of at least 32 characters.
4. Set `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
5. Optionally set `MONGODB_URI`; without it, the server uses temporary in-memory storage.
6. Run `npm install`.
7. Run `npm start`.
8. Open `http://localhost:3000`.
9. Admin: `http://localhost:3000/admin`.
10. Health: `http://localhost:3000/api/health`.

## Render deployment
Create a Render Web Service from the GitHub repository. The included `render.yaml` uses `backend` as the root directory, `npm install` as the build command, `npm start` as the start command, and `/api/health` as the health check.

Set these Render environment variables: `JWT_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `MONGODB_URI`, and `CORS_ORIGINS`. Never commit a real `.env` file or secrets.

## Important
The in-memory database is a fallback for development only. Use MongoDB for persistent production data. Admin credentials and JWT secrets belong in server environment variables, not in frontend code.
